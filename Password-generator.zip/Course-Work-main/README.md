# Course-Work
TKH-Coventry
Download zip file, unzip it, and open the LCG.py from its directory file, DO NOT CHANGE PLACE.
seed.txt/.py files must be in the same file as the code
